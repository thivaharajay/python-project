# def main():
#     x=[[1,2],[3,4]]
#     for i in x:
#         print (i)
#         print (i[0])
#         i[0]=str(i[0])
#     print (x)
# main
# def main():
#  x=[-1,0,1]
#  for k in range(98):
#      x.append(x[k])
#      print (x[100])
# main()
# def main():
#     x=int(input("enter the value:"))
#     b,c=0,1
#     for i in range(x):
#         print(b)
#         b,c=c,b+c
#
# main()

# def main():
#     x=int(input("x"))
#     y=int(input("y"))
#     while (y>0):
#         x,y=y,(x%y)
#     print(x)
# main()
# def main():
#    n=int(input("n"))
#    for i in range (1,n):
#        for j in range (i):
#           # print(i,j)
#            print("#",end='')
#        print("")
#
# main()
# def main():
#     x="ajay.health"
#     print(x[0:5])
#     print(x.split(".")[0])
#     print(x[len(x)//2])
# main()

# def main():
#     n=input("decode msh :  ")
#     print(n,end='')
#     p=1
#     z=0
#     while n>0:
#         z=z+n%10 *p
#         p=p*8
#         n=n//10
# main()
def main():
    f=input("file  :")
    op=open("f","r")
    re=op.read()
    lines=re.lower()
    for i in lines.split():
        count[i]+=1
    d={k:0 for k in lines}