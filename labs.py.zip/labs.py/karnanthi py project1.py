#Author : Erabelly Kranthi Kumar
#student Id:22148326
#Project 1

#os module import
import os

#readiing three input for happiness csv

def inputs():
    """
    takes use input for csv file name, metric and action and returns all as tuple
    """
    input_filename = input("Enter name of file containing World Happiness computation data: ")
    if not os.path.isfile(input_filename):
        print("File Not Found")
        exit(0)

    input_metric = input("Choose metric to be tested from: min, mean, median, harmonic_mean: ").lower()
    if input_metric.lower() not in ['min', 'mean', 'median', 'harmonic_mean']:
        print("Invalid metric")
        exit(0)

    input_action = input(
        "Chose action to be performed on the data using the specified metric. Options are list, correlation ").lower()
    if input_action.lower() not in ['list', 'correlation']:
        print("Invalid action")
        exit(0)

    return (input_filename, input_metric, input_action)

#read input csv file and convert to float value
def create_csv_object(input_filename):
    """
    reads the file and returns list of lists.
    """
    with open(input_filename, 'r') as f:
        rows = f.readlines()
    results = []
    for row in rows[1:]:
        parts = row.strip().split(',')
        new_parts = []
        new_parts.append(parts[0])
        for x in parts[1:]:
            if x:
                new_parts.append(float(x))
            else:
                new_parts.append(None)
        results.append(new_parts)
    return results

#column table to put in dictionary to get all the list to normalise records

def prepare_colums(table):
    """
    prepares dictionary of columns using the list of list.
    """
    columns = {"countries": [],
               "life_ladders": [],
               "gdp": [],
               "social_support": [],
               "healthy_life": [],
               "freedom": [],
               "generosity": [],
               "confidence": []}
    for row in table:
        columns['countries'].append(row[0])
        columns['life_ladders'].append(row[1])
        columns['gdp'].append(row[2])
        columns['social_support'].append(row[3])
        columns['healthy_life'].append(row[4])
        columns['freedom'].append(row[5])
        columns['generosity'].append(row[6])
        columns['confidence'].append(row[7])
    return columns

# prepare min max list from normalise data scaling min value to 0 and max value to 1.

def min_max_normalise(data, col_names):
    """
    grabs minimum value, maximum value and normalises the data which is scaled between 0 and 1
    """
    norm = {}
    for colom in col_names:
        minimum = min(x for x in data[colom] if x is not None)
        maximum = max(x for x in data[colom] if x is not None)
        norm[colom] = []
        for item in data[colom]:
            if item is None:
                score = 0
            else:
                score = (item - minimum) / (maximum - minimum)
            norm[colom].append(score)
    return norm

# based on given input metric is calculated like min, mean, medain and harmonic mean
def calculate_values(norm, columns, size, metric):
    """
    Calculates value for the given input metric from the normalised values
    """
    metrics = []

    for i in range(size):
        n = 0
        temp_list = []
        for column in columns:
            temp_list.append(norm[column][i])

        total = 0.0
        for t in temp_list:
            if t != 0:
                n += 1
                total += t

        if metric == "mean":
            v = round(total / n, 4)

        if metric == "median":

            temp_list.sort()
            l = len(temp_list)
            median_elem = int(l / 2)
            if l % 2 == 0:
                v = round((temp_list[median_elem - 1] + temp_list[median_elem]) / 2, 4)
            else:
                v = round(temp_list[median_elem - 1], 4)

        if metric == "harmonic_mean":
            hsum = 0
            for item in temp_list:
                if item != 0:
                    hsum += 1 / item
            v = round(n / hsum, 4)

        if metric == "min":
            v = round(min(temp_list), 4)
        metrics.append(v)
    return metrics

# correlation calculated based on the given metric 

def calculate_spearman(ladders, metrics):
    """
    calculates and returns spearman correlation coefficient and returns it using ladder score and given input metric.
    """
    sum_squared = 0
    ranked_ladders = calculate_rank(ladders)
    ranked_metrics = calculate_rank(metrics)
    n = len(ranked_ladders)
    for i in range(n):
        di = ranked_ladders[i] - ranked_metrics[i]
        di2 = di * di
        sum_squared += di2
    s_rank = 1 - ((6 * sum_squared) / (((n * n) - 1) * n))
    return s_rank

# the list is sorted in descending order based on metrics with country name

def calculate_list(countries, metrics):
    """
    prepares the list based on the metric's descending order associated with country name
    """
    filtered_metric = []
    n = len(countries)
    for i in range(n):
        filtered_metric.append((countries[i], metrics[i]))
    filtered_metric.sort(key=sort_key, reverse=True)
    return filtered_metric

# the function sorts the list of tuples

def sort_key(value):
    """helper function to sort list of tuples"""
    return value[1]

#rank of function is calcuated based on sperman formula
def calculate_rank(vector):
    """helper function to calculate spearman's rank. this method calculates rank"""
    a = {}
    rank = 1
    for num in sorted(vector):
        if num not in a:
            a[num] = rank
            rank = rank + 1
    return [a[i] for i in vector]

# calling the main function
def main():
    """the main method handles all other function calls"""
    input_filename, input_metric, input_action = inputs()
    table = create_csv_object(input_filename)

    data = prepare_colums(table)

    normalized = min_max_normalise(data, ["gdp", "social_support", "healthy_life", "freedom", "generosity", "confidence"])

    metrics = calculate_values(normalized, ["gdp", "social_support", "healthy_life", "freedom", "generosity", "confidence"], len(normalized['gdp']), input_metric)

    if input_action == "list":
        print("Ranked list of countries' happiness scores based the", input_metric, "metric")
        lst = calculate_list(data['countries'], metrics)
        for l in lst:
            print(l[0], l[1])
    else:
        cor = calculate_spearman(data['life_ladders'], metrics)
        print("The correlation coefficient between the study ranking and the ranking using the", input_metric, "metric is", round(cor, 4))


main()
