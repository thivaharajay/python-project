#propject2
import os

def get_file(filename):

    if filename[-4:] != ".txt":
        filename += ".txt"
    if not os.path.isfile(filename):
        return None
    try:
        f = open(filename, "r")
        file = f.read()
        list=[]
        lower=file.lower()
        list.append(lower)
        print (list)
        f.close()
    except IOError:
        return None
    return list

def sent_par(input_file):
    paragraph_count=0
    for file in input_file:
        para=file.split("\n\n")
        count_par=0
        for i in para:
            count_par+=1
    print ("No of paragraphs in text file:****",count_par)
    count_sent =0
    for file in input_file:
        count_sent+=((file.count('.') + file.count('!') + file.count('?'))/count_par)
    print ("Sentance_per_par     ",count_sent)
    return count_par,count_sent
def listing(input_file):
    my_list=['.',',','-',';','also','although','and','as','because','before','but','for','if','nor',
             'of','or','since','that','though','until','when','whenever','whereas','which','while','yet']
    # dic={x:my_list.count(x) for x in my_list }
    # print(dic)
    symbols=[]
    for i in input_file:
        for j in i:
            if j in [",",";","-"]:


                symbols.append(j)

    #print (symbols)






def main():
    filename=input("Profile of text ")
    input_file=get_file(filename)
    count=sent_par(input_file)
    # print ("Sentance_per_par     ", count_sent)
    listing(input_file)






main()
