import os


def is_filename_valid(filename):
    """
    Checks whether the file exists or not.
    :param filename: name of the file
    :return: boolean true if file exists, false otherwise
    """
    return os.path.isfile(filename.strip())


def read_file(filename):
    """
    Opens and reads a file and returns all of its content.
    :param filename: name of the file
    :return: file content
    """
    handle = open(filename, 'r')
    content = handle.read()
    handle.close()

    return content


def get_blank_profile():
    """
    Returns a default/blank profile.
    :return: profile as dictionary
    """
    return {
        '\'': 0, ',': 0, '-': 0, ';': 0, 'also': 0, 'although': 0, 'and': 0,
        'as': 0, 'because': 0, 'before': 0, 'but': 0, 'for': 0, 'if': 0, 'nor': 0,
        'of': 0, 'or': 0, 'sentences_per_par': 0, 'since': 0, 'that': 0, 'though': 0,
        'until': 0, 'when': 0, 'whenever': 0, 'whereas': 0, 'which': 0,
        'while': 0, 'words_per_sentence': 0, 'yet': 0
    }


def remove_hyphens(content):
    """
    Removes double hyphens from the content.
    :param content: text content
    :return: content with double hyphens replaced with space
    """
    return content.replace('--', ' ')


def get_paragraphs(content):
    """
    Builds paragraphs from text content (using double new-line character).
    :param content: text content
    :return: list of paragraphs
    """
    return content.split('\n\n')


def combine_lines(lines):
    """
    Builds a single-line text from multi-line text content.
    :param lines: text lines (with new-line characters)
    :return: single-line text
    """
    return lines.replace('\n', ' ')


def is_sentence(word):
    """
    Checks whether the word ends a sentence.
    :param word: a word
    :return: boolean true if word ends a sentence, false otherwise
    """
    size = len(word)
    if size == 0:
        return False

    # dot, question mark, exclamation mark followed by space
    ends = ['.', '?', '!']
    last_char = word[-1]
    if last_char in ends:
        return True

    # dot, question mark, exclamation mark followed by quotes or whitespace
    if size > 1:
        ends2 = ['\'', '"', '\t', '\r', '\n']
        second_last_char = word[-2]
        if second_last_char in ends and last_char in ends2:
            return True

    return False


def has_comma(word):
    """
    Checks whether the word contains a comma.
    :param word: a word
    :return: boolean true if word contains a comma, false otherwise
    """
    if len(word) > 0:
        return ',' in word

    return False


def has_hyphen(word):
    """
    Checks whether the word contains a hyphen building a compound-word.
    :param word: a word
    :return: boolean true if the word is a compound-word, false otherwise
    """
    if len(word) > 2:
        return '-' in word and not word.startswith('-') and not word.endswith('-')

    return False


def has_semicolon(word):
    """
    Checks whether the word contains a semicolon.
    :param word: a word
    :return: boolean true if the word contains a semicolon, false otherwise
    """
    if len(word) > 0:
        return ';' in word

    return False


def has_apostrophe(word):
    """
    Checks whether the word contains an apostrophe.
    :param word: a word
    :return: boolean true if the word contains an apostrophe, false otherwise
    """
    if len(word) > 2:
        return '\'' in word and not word.startswith('\'') and not word.endswith('\'')

    return False


def remove_punctuations(word):
    """
    Strips the punctuations from word's start and end.
    :param word: a word
    :return: word without punctuations at start and end
    """
    punctuations = '!"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~'
    return word.strip(punctuations)


def is_conjunction(word):
    """
    Checks whether the word is a conjunction.
    :param word: a word
    :return: boolean true if the word is a conjunction, false otherwise
    """
    conjunctions = [
        'also', 'although', 'and', 'as', 'because', 'before', 'but',
        'for', 'if', 'nor', 'of', 'or', 'since', 'that', 'though',
        'until', 'when', 'whenever', 'whereas', 'which', 'while', 'yet'
    ]
    return word in conjunctions


def normalize_profile(profile, base):
    """
    Normalizes all the item counts in profile using the base.
    This method updates received profile in place and does not create/return new profile.
    :param profile: a dictionary with items and corresponding counts
    :param base: denominator to normalize
    :return: None
    """

    # we don't want to normalize 'words_per_sentence' and 'sentences_per_par'
    items = list(profile.keys())
    items.remove('words_per_sentence')
    items.remove('sentences_per_par')

    for item in items:
        profile[item] /= base


def prepare_profile(content, normalize=False):
    """
    Prepares a profile (dictionary of items and corresponding counts).
    This method also normalizes the profile if "normalize" argument is boolean true.
    :param content: text content
    :param normalize: boolean indicating whether to normalize the profile or not
    :return: profile (dictionary of items and corresponding counts)
    """
    sentence_count = 0
    word_count = 0
    profile = get_blank_profile()

    content = remove_hyphens(content)
    paragraphs = get_paragraphs(content)

    for paragraph in paragraphs:
        paragraph = combine_lines(paragraph)

        words = paragraph.split(" ")
        for word in words:
            if len(word) == 0:
                continue

            if is_sentence(word):
                sentence_count += 1

            if has_comma(word):
                profile[','] += 1

            if has_semicolon(word):
                profile[';'] += 1

            if has_hyphen(word):
                profile['-'] += 1

            # punctuation removal helps properly identifying apostrophe and conjunction words
            word = remove_punctuations(word)

            if has_apostrophe(word):
                profile['\''] += 1

            if is_conjunction(word):
                profile[word] += 1

            word_count += 1

    paragraph_count = len(paragraphs)
    profile['sentences_per_par'] = sentence_count / paragraph_count
    profile['words_per_sentence'] = word_count / sentence_count

    # normalize if needed
    if normalize:
        normalize_profile(profile, sentence_count)

    return profile


def print_profile(profile):
    """
    Prints profile in readable format.
    :param profile: a dictionary of items and corresponding counts
    :return: None
    """

    # sorting is needed to match the sample output
    items = sorted(profile.keys())

    for item in items:
        print("{}\t{:.4f}".format(item, profile[item]))


def calculate_distance(profile1, profile2):
    """
    Calculates the distince between items in profile 1 and items in profile 2.
    :param profile1: a dictionary holding profile 1
    :param profile2: a dictionary holding profile 2
    :return: calculated distance
    """

    sum = 0.0

    # prepare sum of squared differences
    for item in profile1.keys():
        diff = profile1[item] - profile2[item]
        diff_squared = diff * diff
        sum += diff_squared

    # number with power 0.5 is a square-root.
    return sum ** 0.5


def main(textfile1, arg2, normalize=False):
    """
    Start the program and handle life-cycle of the program.
    :param textfile1: name of the file for profile 1
    :param arg2: "listing" as a string or name of the file for profile 2
    :param normalize: boolean indicating whether to normalize profile(s) or not
    :return: None
    """

    # stop program if any of the files do not exist
    if not is_filename_valid(textfile1):
        print('Provided file "{}" does not exist.'.format(textfile1))
        return

    if arg2 != "listing":
        if not is_filename_valid(arg2):
            print('Provided file "{}" does not exist.'.format(arg2))
            return

    # read file and prepare profile 1
    content1 = read_file(textfile1)
    profile1 = prepare_profile(content1, normalize)

    # print profile 1
    if arg2 == "listing":
        print("profile of text {}".format(textfile1))
        print_profile(profile1)

    # compare profiles
    else:
        # read file and prepare profile 2
        content2 = read_file(arg2)
        profile2 = prepare_profile(content2, normalize)

        # calculate and print distance
        distance = calculate_distance(profile1, profile2)
        print("The distance between the two texts is: {:.4f}".format(distance))


if __name__ == '__main__':
    #main('sample1.txt','listing')
    main('sample1.txt', 'sample2.txt', normalize=True)
