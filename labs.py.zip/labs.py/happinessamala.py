import csv
import sys
print(sys.version)
import math
from collections import defaultdict
import statistics
import numpy as np
import pandas as pd
 

# Calculate min of World Happiness data
def min(f):
   df=pd.read_csv(f)
   print('min value:'+str(df.min()))
   
   
# Calculate mean of World Happiness data
def mean (f):
    next(f)
    average = 0
    Sum = 0
    row_count = 0
    list3=''
    list4= 0
    life_ladder=0   
    for row in f:
        row_count+=1
        column_index=0
        column_name=''
        for column in row.split(','):
            # print(row)
            column_index+=1
            # print(column_index)

            if(column_index==1):
                # print('Column '+column)
                column_name=(column)
            if(column_index==2):
                # print('Column '+column)
                    life_ladder=life_ladder+float(column)
                #life_ladder=life_ladder+' ('+str(Sum/ len(column))+')'+'\n'
        else:
            try:
                n=float(column)
            except:
                print('')
            
        Sum += n
            # print('The Average is:'+column_name+' '+str(Sum/ len(column)))
        list4=list4+float(Sum/ len(column))
        list3=list3+' ('+column_name+','+str(Sum/ len(column))+')'+'\n'
        
       
    
    #close file
    f.close()

    #call show mean data in list or calculate correlation
    listMeanShow(list3,list4,life_ladder,row_count)
    




def listMeanShow(list3,list4,life_ladder,row_count):
    user_input = input('Chose action to be performed on the data using the specified metric. Options are list, correlation :')
    if(user_input=='list'):
       print(sortGroup(list3))
    elif(user_input=='correlation'):
        calculate_correlation(list4,life_ladder,row_count)#print('['+list4+']') 
    else:
        print('Invalid option')

def calculate_correlation(list4,life_ladder,row_count):
    corr=0
    corr=(((row_count * (list4+life_ladder)) - (list4*life_ladder))/ (math.sqrt(row_count) * (list4+list4) - math.sqrt(list4)*(row_count*life_ladder) - math.sqrt(life_ladder)))
    print(corr)

# Calculate Median of happiness data
def median(f):
    list3=''
    row_count=0
    list4=0
    next(f)
    for row in f:
        list_imime=row.split(',')
        list_getLadder=row.split(',')   
        listShow=list_imime.pop(0)
        listLadder=list_getLadder.pop(1)
        list_ladderData=0
        list_ladderData=list_ladderData+float(listLadder)
        try:
            n_num=[float(i) for i in list_imime]
        except:
            print('')
        # try:
        #   n_num = [float(i) for i in list_imime]
        # except:
        #   print('test')   

     # print(n_num)
        n = len(n_num) 
        # print(n)
        n_num.sort() 
        if n % 2 == 0:
            median1 = n_num[n//2] 
            median2 = n_num[n//2 - 1] 
            median = (median1 + median2)/2
            # print("Median is: " + str(median)) 
        else: 
            median = n_num[n//2] 
        
        
        # print("Median is: " +listShow+' '+ str(median))
        list3=list3+' ('+listShow+','+ str(median)+')'+'\n'
        list4=list4+float(median)
    # print(list3)
    row_count+=1
    f.close()
    showCalculateData(list3,list4,list_ladderData,row_count)
    
# Calculate Harmonic Mean of happiness data
def harmonic_mean(f): 
     list3=''

     # list_ladderData=''
     row_count=0
     list4=0
     next(f)
     for row in f:
        row_count+=1
        # print(row.split()[0])
        column_name=''
        # for column in row.split(','):
            # print(row) 
        list_imime=row.split(',')
        list_getLadder=row.split(',')
                # print(list_imime)
        listShow=list_imime.pop(0)
        listLadder=list_getLadder.pop(1)
        list_ladderData=0
        list_ladderData=list_ladderData+float(listLadder)
        
        try:
            n_num=[float(i) for i in list_imime]
        except:
            print('')

        list2 = [(i > 0) * i for i in n_num]
       
        list3=list3+' ('+listShow+" "+str(statistics.harmonic_mean(list2))+')'+'\n'
        list4=list4+float(statistics.harmonic_mean(list2))
     
            
     f.close()
     showCalculateData(list3,list4,list_ladderData,row_count)
     
# Sort data 
def sortGroup(str):
    arr = str.split(',')
    arr = sorted(arr)
    return ','.join(arr)




# Show Median and Harmonic mean Data in list form or calculate correlation
def showCalculateData(data,list4,list_ladderData,row_count):
    user_input = input('Chose action to be performed on the data using the specified metric. Options are list, correlation :')
    if(user_input=='list'):
        print(sortGroup(data))

    elif(user_input=='correlation'):
def main():
        calculate_correlation(list4,list_ladderData,row_count)
    else:
        print('Invalid option')


    # Input from user to get csv file
    user_input = input('Enter name of file containing World Happiness computation data: ')
    try:
        f=open(user_input+'.csv')
    except:
        print('File not available here !!')
        sys.exit()
    # f=open(user_input+'.csv')
    

    # Input from user to get test metric
    input_metrictype = input ("Choose metric to be tested from: min, mean, median, harmonic_mean :")
    test_metric = str(input_metrictype)
    print ("The number you entered is: ", test_metric)

    # Redirect to user on a function with the file chosen 
    if(test_metric=='mean'):
      mean(f)
    elif(test_metric=='median'):
      median(f)
    elif(test_metric=='harmonic_mean'): 
      harmonic_mean(f)
    elif(test_metric=='min'): 
      min(f)
    else:
      print('Invalid option')
      
    
# Converts the string into a integer. If you need
# to convert the user input into decimal format,
# the float() function is used instead of int()
    #

# Prints in the console the variable as requested
# print ("The number you entered is: ", test_number)   
  

if __name__== "__main__":
  main()

  


