# def fib (x):
#     nterms =5
#     #nterms = int(input("enter")
#     n1=0
#     n2=1
#     count =0
#     if nterms<=0:
#         print("enter a positive number")
#     elif nterms==1:
#         print("series upto",nterms,":")
#         print(n1)
#     else:
#         print("series",nterms,":")
#         while count < nterms:
#             print(n1,end=",")
#             n3=n1+n2
#             n1=n2
#             n2=n3
#             count=+1
# fib(5)
###################
# def main():
#     print("training program")
#     x=float(input("Enter the number :"))
#     i=0
#     for i in range (10):
#         x=3.7*x*(1-x)
#         print(x)
#
# main()
######lab2###################
# def main():
#     x="hello my name is 'ajay'"
#     y=x="hello my 'name' is ajay "
#     print(x)
#     print(y)
# main()
##########3
#
# def main():
#     print('''this is my name
# ajay is here
# he is living in nedlands''')
# main()

###################
# def main():
#     print('heloo',end='')
#     print("i am ajay")
# main()


# ##################333
# def main():
#     n=int(input("enter the fact number:"))
#     factorial =1
#     if n<0:
#         print("please enter postive number")
#     elif n==0:
#         print("0 is 1")
#     else:
#         for i in range(1,n+1):
#             factorial = factorial*i
#             print("factorial",factorial)
# main()
################
# def main():
#     n=int(input("enter:"))
#     if n==0:
#         print("1")
#     elif n<0:
#         print("enter posiitve numbers")
#
#     else:
#         print("factorial",n*(n-1))
# main()
#######################3
# import math
# # print("pi is:",math.pi)
# x=int(input("enter the value:"))
# y=math.factorial(x)
# print(y)

###############10 11 12 ###
# def main():
#     print("This program illustrates a chaotic function")
#     x = float(input("Enter a number between 0 and 1: "))
#     for i in range(10):
#         x = 3.9 * x * (1 - x)
#     #if(i==9):
#         print(x)
# main()

# def sing(person):
#     happy()
#     happy()
#     print("happy birthday",person +".")
#     happy()
# def happy():
#     print("Happy bday to you")
# def main():
#     person = input("who gonna embrasse")
#     sing(person)
# main()

# import math
# def square(x,y):
#     x=math.sqrt(square(x-y)+square(x+y))
#     print(x)
# square(2,5)

# workshop exercise
# import math
# def meansd(nums):
#     return sum(nums)/len(nums)
# def standearddeviation(nums):
#     sd=0
#     mu =meansd(nums)
#     for k in nums:
#         sd=sd+k**2
#     return math.sqrt(sd/len(nums)-mu**2)
#
# def main():
#     nums =range(10)
#     print("mean value",meansd(nums))
#     print("standard deviation",standearddeviation(nums))
#
# main()
#
# def mean(nums):
#     sum=0
#     count =0
#     for i in nums:
#         sum = sum+i
#         count = count+1
#     means=sum/count

# def odd():
#     num=int(input("enter the number"))
#     for i in range(1,num+1):
#         if((i%2!=0) & (i%5!=0)):
#             print(i)
# odd()
# import math
# def main():
#     r=int(input("Enter the radius:"))
#     sphere=(4*math.pi*(r**2))
#   #  print("sphere of radius:",sphere)
#     m=float(input("enter material :"))
#     total=m*sphere
#     print(total)
# main()
# def sum(N) :
#     sum=0
#     for i in range(N) :
#         if (i == 2) or (i == 3):
#             sum += 1
#     print(sum)
#     return(sum)

#
# sum

#workshop2
# def day(day,month,year):
#     y=year
#     if (month ==1) or (month ==2):
#       y -=1
#     y2 =y%100
#     c =y//100
#     if (month >=1):
#         m=month-2
#     else:
#         m=month+10
#     dayno=(day + int(2.6*m-0.2)+y+(y//4)+(c//4)-2*c)%7
#     print(dayno)
# day(24,3,2019)
#############lab4$################
# def main():
#     a="mypgrogram.exe"
#     # b=a[:-4]
#     b=(len(a))/2
#     c=a[6]
#     print(c)
# main()
# def funA(a):
#     for x in range(3):
#         a.append(funB(a))
#     return a
# funA([2,3])
# def funB(y):
#     return y[-2]+y[-1]
# funB(3)
# def main():
#     dec=344
#     print("the decimal value are",dec,":" )
#     print("converted to binary--",bin(dec))
#     print(oct(dec))
#     print(hex(dec))
# main()
# def main():
#     word=str(input("ENter the bit"))
#     k=int(input("enter the integer:"))
#     if k>0:
#         s= word[-k:] +word[:-k]
#         print(word[-k:])
#         print(len(word[:-k]))
#         print(s)
# main()
##############lab5#################


# def main():
#     word='00111'
#     k=2
#     b='false'
#     k=k%len(word)
#     print(k)
#     if not b:
#         k=k*-1
#         print(k)
#     print(word[k:]+word[:k])
# main()

# def main():
#     l=[]
#     n=int(input("prime number "))
#     for i in range(2,n+1):
#         if i>1:
#             for j in range(2,i):
#                 if(i%j==0):
#                     break
#             else:
#                 l.append(i)
#                 print(l[1:])
#
# main()
# def main():
#     filenam="sample.txt"
#     z=0
#     fh=open(filenam,'r')
#     words=fh.readline().split()
#     for i in words:
#         if len(i)==4:
#             z=z+1
#     print(z)
#
# main()
# def main():
#     string="/users/micheal/cits1401/exam.doc"
#     m=string.split("/")[-1].split('.')[0]
#     print(m)
# main()
# def main():
#     filenam = "sample.txt"
#     z=0
#     fh=open(filenam,'r')
#     words=fh.readline().split()
#     for m in words:
#         for n in m:
#
#             d={key:0 for key in n}
#             print(d)
#             for l in n:
#
#                 for key in d:
#                     if l == key:
#                         d[key]+=1
#     print(d)
#
#    # print(words)
# main()


# def main():
#     inn=5
#     l=[]
#     a,b=0,1
#     for i in range(5):
#         print(a)
#         a,b=b,a+b
# main()

# def main():
#     l=[]
#     fh=open("marks.txt","r")
#     read1=fh.readlines()
#     for i in read1:
#        l.append(i.split())
#     print(l)
# main()
# def main():
#     data = [3, 1, 9, 2, 4]
#     n = len(data)
#     for i in range(n):
#         for j in range(1, n):
#             if data[j - 1] > data[j]:
#              (data[j - 1], data[j]) = (data[j], data[j - 1])
#     print(data)
# main()
#
# import os
# def getfile(f):
#     count = []
#
#     # Check if file exists.
#     if not os.path.isfile(f):
#         print("File %s doesn't exists so returning empty list " %(f))
#         return []
#     else:
#         f = open(f, 'r')
#         wordlist = f.read()
#         lines = wordlist.lower()
#         for i in lines.split():
#             count[i] += 1
#         dictn = {k:0 for k in lines}
#
#     print (dictn)
# getfile("sample.txt")
#def getfile(f):
###    count = []
###
###    # Check if file exists.
###    if not os.path.isfile(f):
###        print("File %s doesn't exists so returning empty list " %(f))
###        return []
###    else:
###        f = open(f, 'r')
###        wordlist = f.read()
###        lines = wordlist.lower()
###        for i in lines.split():
###            count[i] += 1
###        dictn = {k:0 for k in lines}
###
###    print (dictn)
# def main():
#     num =[[2,3],[3,[8],4]]
#     flat_list = []
#     for sublist in num:
#         for item in sublist:
#             flat_list.append(item)
#     print(flat_list)
# main()
def main():
    lst = [[1,2],[3,4]]
    i = 0
    while i < len(lst):
        while True:
            try:
                lst[i:i + 1] = lst[i]
            except (TypeError, IndexError):
                break
        i += 1
    print(lst)
main()
# def main():
#     lst = [[1], 2,[7,[8,7]], 7, 8, [],[[[]]]]
#     l=len(lst)
#     print(l)
# main()